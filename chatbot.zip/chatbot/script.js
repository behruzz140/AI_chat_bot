let OPENAI_API_KEY = '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';

async function sendMessage() {
    const userInput = document.getElementById('userInput').value;
    if (!userInput) return;

    const chatbox = document.getElementById('chatbox');
    chatbox.innerHTML += `<div class="user-message">You: ${userInput}</div>`;
    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + OPENAI_API_KEY
            },
            body: JSON.stringify({
                "model": "gpt-4o-mini",
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a helpful assistant."
                    },
                    {
                        "role": "user",
                        "content": userInput
                    }
                ]
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();

        if (data.choices && data.choices[0] && data.choices[0].message) {
            chatbox.innerHTML += `<div class="bot-response">Bot: ${data.choices[0].message.content}</div>`;
        } else {
            chatbox.innerHTML += `<div class="bot-response">Bot: Sorry, there was an error.</div>`;
        }
    } catch (error) {
        chatbox.innerHTML += `<div class="bot-response">Bot: Error - ${error.message}</div>`;
    }

    document.getElementById('userInput').value = '';
    chatbox.scrollTop = chatbox.scrollHeight;
}

// Enter tugmasi bosilganda xabar jo'natilishini ta'minlash
document.getElementById('userInput').addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        event.preventDefault(); // Enter tugmasi bilan sahifani yangilashni to'xtatish
        sendMessage(); // Xabarni jo'natish
    }
});
